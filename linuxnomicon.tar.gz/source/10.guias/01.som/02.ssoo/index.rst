Sistemas operativos
===================
El tema presenta muy someramente qué es un sistema operativos y cuáles son las
funciones principales que llevan a cabo. Enumera además los distintos tipos de
sistemas operativos que hay y cómo se encargan de gestionar los recursos.

.. rubric:: Contenidos

.. toctree::
   :maxdepth: 2
   :glob:

   [0-9]*
