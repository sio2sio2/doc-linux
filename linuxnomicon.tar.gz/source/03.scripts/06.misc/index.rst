.. highlight:: bash

Otros aspectos
**************
Trataremos, por último, algunos aspectos particulares que pueden mejorar la
programación de nuestros scripts.

.. rubric:: Contenidos

.. toctree::
   :glob:
   :maxdepth: 1

   [0-9]*
