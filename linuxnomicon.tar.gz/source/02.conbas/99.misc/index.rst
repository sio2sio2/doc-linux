Miscelánea
==========

Culminamos la presentación de los conceptos básicos, exponiendo algunos asuntos
que, aunque de muy distinta naturaleza, pueden ser muy útiles cuando se
administra un sistema.

**Contenidos**

.. toctree::
   :glob:
   :maxdepth: 2

   [0-9]*

