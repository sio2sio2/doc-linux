Acceso a la información
=======================

Al utilizar un sistema operativo, nuestro principal objetivo es poder acceder a
la información que este ofrece a través de programas y datos almacenados en
disco.

**Contenidos**

.. toctree::
   :glob:
   :maxdepth: 2

   [0-9]*
