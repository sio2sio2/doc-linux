.. include:: /99-ejercicios/07-io.rst
