Administración básica
=====================

Cualquier uso del sistema, por muy básico que sea, requiere unas tareas mínimas
de administración tales como:

* :ref:`Gestionar usuarios <gesusu>`.
* Instalar y desinstalar software.
* Gestionar los procesos del sistema.
* Configurar la red.

**Contenidos**

.. toctree::
   :glob:
   :maxdepth: 2

   [0-9]*
