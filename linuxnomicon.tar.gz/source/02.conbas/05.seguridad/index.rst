.. _permusu:

Seguridad en el sistema de ficheros
===================================

Bajo este epígrafe trataremos el modo básico que existe en linux para asegurar
el sistema y los datos, esto es, la gestión de usuarios y permisos. Son
conceptos íntimamente ligados ya que la exustencia de distintos usuarios se
justifica por la necesidad de asociarles distintos permisos sobre los recursos
del sistema y los datos que se almacenan.

**Contenidos**

.. toctree::
   :glob:
   :maxdepth: 2

   [0-9]*
