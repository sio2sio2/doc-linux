.. _crypto:

************
Criptografía
************

Bajo el epígrafe se exponen algunos conceptos generales sobre criptografía y se
ilutra el uso de algunas herramientas de *software* libre que la usa como
GnuPG_.

.. toctree:: 
   :glob:
   :maxdepth: 2

   [0-9]*

.. _GnuPG: https://www.gnupg.org/
