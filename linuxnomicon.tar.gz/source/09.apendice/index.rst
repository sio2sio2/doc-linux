Apéndices
=========
El epígrafe está dedicado a temas relacionados con el sistema, pero no
propios de él.

.. toctree:: 
   :glob:
   :maxdepth: 2

   [0-9]*/index
