Conceptos avanzados de redes
============================

.. Tipos de interfaces en linux:
   https://developers.redhat.com/blog/2018/10/22/introduction-to-linux-interfaces-for-virtual-networking/

.. Espacios de nombres en redes: ¿Esto qué es?

   https://blogs.igalia.com/dpino/2016/04/10/network-namespaces/

   La documentación de Wireguard pone un ejemplo de aplicación:

   https://www.wireguard.com/netns/#the-new-namespace-solution

.. _ip:

.. todo:: Introducción...

.. toctree:: 
   :glob:
   :maxdepth: 2

   [0-9]*
   [0-9]*/index
