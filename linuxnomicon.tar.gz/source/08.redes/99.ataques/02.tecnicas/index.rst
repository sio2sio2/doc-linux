Técnicas
********
Conocidos los tipos posibles de ataques contra comunicaciones informáticas, es
interesante analizar algunas técnicas muy comunes para llevarlos a cabo y, por
supuesto, los correspondientes métodos para atajarlos o minimizarlos:

.. toctree::
   :glob:
   :maxdepth: 2

   [0-9]*
