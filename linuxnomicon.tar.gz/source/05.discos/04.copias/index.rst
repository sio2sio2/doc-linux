Copias
======
Bajo el epígrafe trataremos tres enfoques distintos sobre las copias de disco:

* las **copias de seguridad**, que permiten salvaguardar los datos ante fallos o
  accidentes en el almacenamiento.
  
* Las **clonaciones** con las que se copian sistemas enteros con el propósito,
  normalmente, de reproducir una misma instalación en muchas máquinas.

* Las **instalaciones desatendidas** que no son copias en sí, pero permiten la
  instalación automatizada de un mismo sistema en múltiples ordenadores.

.. toctree::
   :glob:
   :maxdepth: 1

   [0-9]*
