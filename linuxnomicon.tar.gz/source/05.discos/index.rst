.. _disks:

Dispositivos de almacenamiento
==============================

La información del servidor que es al fin lo más valioso, se almacena en
los discos, de modo que es fundamental planificar convenientemente cómo se
tratarán. En paricular, trataremos:


.. toctree::
   :glob:
   :maxdepth: 2

   [0-9]*/index
