Chuleta
=======
.. warning:: Bajo este epígrafe se enlazan exclusivamente aquellos otros
   epígrafes indispensables para hacer una configuración mínima. Reducir su
   lectura a ellos, es absolutamente desaconsejable en la medida en que
   impedirá entender absolutamente nada.

* :ref:`Instalación <nginx-install>`.
* :ref:`Configuración básica <nginx-basico>`.
* :ref:`Generación de un certificado autofirmado <auto-cert>` y
  :ref:`configuración de la conexión segura <nginx-https>`.
* :ref:`Contenido dinámico con PHP <nginx-php>`.
* :ref:`Control de accesos mediante autenticación <nginx-auth>`
