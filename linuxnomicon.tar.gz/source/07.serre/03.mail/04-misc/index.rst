Otros aspectos
**************
Bajo el epígrafe se cubren otros aspectos relacionados con el servicio de
correo:

.. toctree::
   :glob:
   :maxdepth: 1

   [0-9]*/index
