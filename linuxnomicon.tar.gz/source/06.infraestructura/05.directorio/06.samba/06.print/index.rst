Impresión
=========

.. rubric:: Enlaces de interés

* `Print server support <https://wiki.samba.org/index.php/Print_server_support>`_
