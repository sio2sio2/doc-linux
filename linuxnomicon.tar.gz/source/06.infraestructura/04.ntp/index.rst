.. _ntp:

Servicio de hora
================
