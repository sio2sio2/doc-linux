.. _dns:

DNS
===

.. todo:: Explicar su utilidad y :file:`/etc/hosts`.

.. toctree::
   :glob:
   :maxdepth: 2

   [0-9]*

.. _ddns:
