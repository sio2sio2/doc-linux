Planificación de tareas
=======================

El epígrafe está dedicado no a la creación de órdenes que se ejecutarán
inmediatamente (como es el caso de todas las que hemos hecho hasta ahora), sino
en el futuro o de forma periódica.

Tradicionalmente, esto ha venido haciéndose en los sistemas *UNIX* con :ref:`at
<at>` y :ref:`cron <cron>` respectivamente, aunque :ref:`systemd` que poco a
poco a ido fagocitando las tareas esenciales del sistema, también ha metido la
cuchara en esto. Revisaremos en los apuntes ambos sistemas.

.. toctree::
   :glob:
   :maxdepth: 2

   [0-9]*
