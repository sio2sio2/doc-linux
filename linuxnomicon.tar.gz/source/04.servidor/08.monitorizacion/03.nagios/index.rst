Sistema de monitorización (`nagios <https://www.nagios.org/>`_)
===============================================================
