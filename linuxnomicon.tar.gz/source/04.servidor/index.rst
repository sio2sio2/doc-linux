Gestión del servidor
====================

Esta sección de los apuntes se dedica a los aspectos relacionados con la gestión
de linux como sistema servidor, esto es, a aspectos que debe conocer un
administrador, pero con los que raramente debe lidiar un usuario que lo use como
sistema de escritorio:

.. toctree::
   :glob:
   :maxdepth: 2

   [0-9]*/index
