<?php
  $baselistdir = getcwd();
  $mlist = substr(strrchr ($baselistdir, "/"), 1);
  $mlistdir = opendir($baselistdir);
  $navlists = $bodylists = "";
  while($file = readdir($mlistdir)) {
    if($file != "." && $file != ".." && $file != "images" && $file != "style"
       && is_dir($baselistdir . "/" . $file)) {
      $navlists.= " | <a href=\"$file\">$file list</a>";
      $bodylists.= "<h2><a href=\"$file\">$file mailing list</a></h2> ";
    }
  }
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang="en">
<head>
 <title>Mailing Lists</title>
 <link rel="stylesheet" type="text/css" media="screen" href="style/screen.css">
</head>
<body>
 <div id="banner">
  <div id="header">
   <div class="banner-left"><img src="images/banner_left.gif" width="17" height="56" border="0" alt="" /></div>
   <div class="banner-text">Mailing List Archives</a></div>
   <div class="banner-right"><img src="images/banner_right.gif" width="10" height="56" alt="" /></div>
  </div>
  <div id="topnav">
   <a href="/">home</a>
<?php echo $navlists; ?>
  </div>
 </div>
 <div id="mailinglists">
  <div id="main">
   <h1>Mailing Lists</h1>
<?php echo $bodylists; ?>
  </div>
 </div>
</body>
</html>
