CREATE DATABASE IF NOT EXISTS tareas;
USE tareas;

GRANT ALL PRIVILEGES ON tareas.* TO operador IDENTIFIED BY 'operador';

CREATE TABLE IF NOT EXISTS Tarea (
   nombre      VARCHAR(50),
   ocupacion   VARCHAR(50)
);

DELETE FROM  Tarea;

INSERT INTO Tarea VALUES ('Pedrito', 'Despiojarse');
INSERT INTO Tarea VALUES ('Pablito', 'Comer doritos');
INSERT INTO Tarea VALUES ('Mariquilla', 'Pintarse la uñas');
INSERT INTO Tarea VALUES ('Manolito', 'Rascarse la barriga');
