<!DOCTYPE html>
<html>
   <head>
      <title>Ejemplo de conexión a una base de datos</title>
      <meta charset="utf-8">
      <style type="text/css">
      <!--
      table {
         border: 2px solid black;
         border-collapse: collapse;
      }
      caption {
         font-weight: bold;
      }
      td, th {
         padding: 2px 4px;
         border: 1px solid black;
      }
      th {
         background-color: #EEE;
      }
      -->
      </style>
   </head>
<?php
   $conn = new mysqli("localhost", "operador", "operador", "tareas");
   $sql = "SELECT * FROM Tarea";
   $result = $conn->query($sql);
?>
   <body>
      <h1>Conexión a MySQL (Ejemplo práctico)</h1>
      <table>
         <caption>Tareas de hoy</caption>
         <tr><th>Nombre</th><th>Tarea</th></tr>
         <?php
            while($row=$result->fetch_object()) {
               echo "<tr><td>".$row->nombre."</td><td>".$row->ocupacion."</td></tr>\n";
            }
         ?>
      </table>
   </body>
</html>
